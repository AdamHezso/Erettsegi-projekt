function kereses(){
    console.log("Keresés gombra kattintás történt");
    var keresett = document.getElementById("search").value;
}